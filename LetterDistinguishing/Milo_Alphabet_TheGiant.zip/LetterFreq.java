package source;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class LetterFreq {

	public static void main(String[] args) throws IOException {
		
		String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String letters = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "0123456789+/";
		
		BufferedReader reader = Resources.openFile_Reader("alphabetToCount");
		
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		//System.out.print("Type in the letters you wish to count: ");
		String inputKeyword = reader.readLine();//keyboard.next();
		
		Resources.closeFile(reader, "alphabetToCount");
		
		ArrayList<String> listOfUpperCaseLetters = new ArrayList<String>();
		ArrayList<String> listOfLowerCaseLetters = new ArrayList<String>();
		ArrayList<String> listOfNumbers = new ArrayList<String>();
		Map<String, Integer> listOfItems = new HashMap<String, Integer>();
		
		for(int i = 0; i < inputKeyword.length(); ++i)
		{
			listOfItems.put(Character.toString(inputKeyword.charAt(i)), 0);
		}
		
		System.out.println("Doing things...");
		
		for(int i = 0; i < inputKeyword.length(); ++i)
		{
			String testString = Character.toString(inputKeyword.charAt(i));
			listOfItems.put(testString, listOfItems.get(testString) + 1);
			
			if(LETTERS.contains(testString))
			{
				if(!listOfUpperCaseLetters.contains(testString))
				{
					listOfUpperCaseLetters.add(testString);
				}
			}
			else if(letters.contains(testString))
			{
				if(!listOfLowerCaseLetters.contains(testString))
				{
					listOfLowerCaseLetters.add(testString);
				}
			}
			else if(numbers.contains(testString))
			{
				if(!listOfNumbers.contains(testString))
				{
					listOfNumbers.add(testString);
				}
			}
			else
			{
				System.out.println("This doesn't match anything: " + testString);
			}
		}
		
		System.out.println("Number of times lower case appears: " + listOfLowerCaseLetters.size());
		System.out.println(listOfLowerCaseLetters);
		System.out.println("Number of times upper case appears: " + listOfUpperCaseLetters.size());
		System.out.println(listOfUpperCaseLetters);
		System.out.println("Number of times numbers appears: " + listOfNumbers.size());
		System.out.println(listOfNumbers);
		System.out.println("Number of times each letter/number appears: ");
		sortMap(listOfItems);
	}
	
	/*String holderString = "";
	int[] sixBitArr = {1,2,4,8,16,32};
	String b64ToIndex = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789/";
	
	public void B64ToIndex(String character)
	{
		if(holderString.length() == 3)
		{
			
		}
		else
		{
			holderString += character;
			
			int index = b64ToIndex.indexOf(character);
			
			boolean finished = false;
			int indexOfArr = 0;
			int[] finalArr = {0,0,0,0,0,0};
			int total = 0;
			while(!finished)
			{
				finalArr[indexOfArr] = 1;
				for(int i = 0; i < 6; ++i)
				{
					if(finalArr[i] == 1)
					{
						total += sixBitArr[i];
					}
				}
			}
		}
	}*/
	
	public static void sortMap(Map<String, Integer> tempMap)
	{
		Set<String> tempStringSet = tempMap.keySet();
		
		Collection<Integer> tempIntCol = tempMap.values();
		
		ArrayList<Integer> tempIntArr = new ArrayList<Integer>(tempIntCol);
		ArrayList<String> tempStringArr = new ArrayList<String>();
		
		for(String str : tempStringSet)
		{
			tempStringArr.add(str);
		} // for(String str : tempStringSet)
		
		System.out.println("*SORTING...*");
		for(int i = 0; i < tempStringArr.size(); ++i)
		{
			for(int j = 0; j < tempStringArr.size(); ++j)
			{
				if(tempIntArr.get(j) > tempIntArr.get(i))
				{
					int tempInt = tempIntArr.get(j);
					tempIntArr.set(j, tempIntArr.get(i));
					tempIntArr.set(i, tempInt);
					
					String tempString = tempStringArr.get(j);
					tempStringArr.set(j, tempStringArr.get(i));
					tempStringArr.set(i, tempString);
				} // if(tempIntArr.get(j) > tempIntArr.get(i))
				
			} // for(int j = 0; j < tempStringArr.size(); ++j)
			
		} // for(int i = 0; i < tempStringArr.size(); ++i)
		
		
		for(int i = tempStringArr.size() - 1; i >= 0; --i)
		{
			System.out.println(tempStringArr.get(i) + " " + tempIntArr.get(i));
		} // for(int i = tempStringArr.size() - 1; i >= 0; --i)	
		System.out.println("*SORT SUCCESFUL*");
	} /** public void sortMap(Map<String, Integer> tempMap) **/
}
